create FUNCTION FUN_GET_ESTE_UTILIZADOR(
  p_username VARCHAR2,
  p_password VARCHAR2)
  RETURN CLOB
IS
  v_utilizador utilizadores%ROWTYPE;
  v_pais       paises%ROWTYPE;
  v_json       CLOB;
  BEGIN
    SELECT
      ID_UTILIZADOR,
      USERNAME,
      PASSWORD,
      NIVEL_PERMISSOES,
      NOME_COMPLETO,
      MORADA,
      TELEMOVEL,
      EMAIL,
      DATA_NASCIMENTO,
      NIC,
      NIF,
      IDADE,
      FOTO,
      SALDO,
      ATIVADO,
      ID_PAIS,
      BANDEIRA,
      NOME,
      MOEDA
    INTO v_utilizador.id_utilizador,
      v_utilizador.username,
      v_utilizador.password,
      v_utilizador.nivel_permissoes,
      v_utilizador.nome_completo,
      v_utilizador.morada,
      v_utilizador.telemovel,
      v_utilizador.email,
      v_utilizador.data_nascimento,
      v_utilizador.nic,
      v_utilizador.nif,
      v_utilizador.idade,
      v_utilizador.foto,
      v_utilizador.saldo,
      v_utilizador.ativado,
      v_pais.id_pais,
      v_pais.bandeira,
      v_pais.nome,
      v_pais.moeda
    FROM UTILIZADORES, PAISES
    WHERE USERNAME = p_username AND password = p_password AND id_pais = paises_id_pais;

    v_json := '{"mensagem": {"id_utilizador":"' || v_utilizador.id_utilizador || '",
          "username":"' || v_utilizador.username || '",
          "password":"' || v_utilizador.password || '",
          "nivel":"' || v_utilizador.nivel_permissoes || '",
          "nome":"' || v_utilizador.nome_completo || '",
          "morada":"' || v_utilizador.morada || '",
          "telemovel":"' || v_utilizador.telemovel || '",
          "email":"' || v_utilizador.email || '",
          "data_nascimento":"' || v_utilizador.data_nascimento || '",
          "nic":"' || v_utilizador.nic || '",
          "nif":"' || v_utilizador.nif || '",
          "idade":"' || v_utilizador.idade || '",
          "foto":"' || v_utilizador.foto || '",
          "saldo":"' || v_utilizador.saldo || '",
          "ativado":"' || v_utilizador.ativado || '",
          ' || fun_get_pais(v_pais.id_pais) || '
          	}}';

    RETURN v_json;
  END FUN_GET_ESTE_UTILIZADOR;