create FUNCTION FUN_GET_PAIS(p_id_pais NUMBER)
  RETURN VARCHAR2 AS
  v_pais paises%ROWTYPE;
  v_json VARCHAR2(500);
  BEGIN
    SELECT *
    INTO v_pais.id_pais,
      v_pais.bandeira,
      v_pais.nome,
      v_pais.moeda,
      v_pais.simbolo_moeda
    FROM paises
    WHERE id_pais = p_id_pais;

    v_json := '"pais":{"id_pais":"' || v_pais.id_pais || '",
            "bandeira":"' || v_pais.bandeira || '",
            "nome_pais":"' || v_pais.nome || '",
            "moeda":"' || v_pais.moeda || '",
            "simbolo":"' || v_pais.simbolo_moeda || '"
            }';

    RETURN v_json;
  END FUN_GET_PAIS;