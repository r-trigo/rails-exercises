create PROCEDURE proc_insert_lista_c_filme(v_id_filme NUMBER, v_nome_categorias VARCHAR2) AS
  v_categoria    CATEGORIAS.NOME%TYPE;
  v_id_categotia CATEGORIAS.ID_CATEGORIA%TYPE;
  CURSOR c_cats IS SELECT regexp_substr(v_nome_categorias, '[^, ]+', 1, level) AS categoria
                   FROM dual
                   CONNECT BY regexp_substr(v_nome_categorias, '[^, ]+', 1, level) IS NOT NULL;
  BEGIN OPEN c_cats;
    LOOP FETCH c_cats INTO v_categoria;
      EXIT WHEN c_cats%NOTFOUND;
      SELECT ID_CATEGORIA
      INTO v_id_categotia
      FROM CATEGORIAS
      WHERE NOME = v_categoria;

      dbms_output.put_line(v_id_filme || ',' || v_categoria);

      INSERT INTO LISTA_CATEGORIAS_FILME (FILMES_ID_FILME, CATEGORIAS_ID_CATEGORIA) VALUES (v_id_filme, v_id_categotia);
    END LOOP;
    CLOSE c_cats;
  END;