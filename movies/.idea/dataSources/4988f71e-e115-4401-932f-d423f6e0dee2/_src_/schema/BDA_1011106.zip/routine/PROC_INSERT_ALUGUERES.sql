create PROCEDURE proc_insert_alugueres
  (p_id_utilizador NUMBER, p_filme VARCHAR2)
AS
  v_id           ALUGUERES.ID_ALUGUER%TYPE;
  v_id_of        ALUGUERES.ID_ALUGUER%TYPE;
  v_utilizador   ALUGUERES.UTILIZADORES_ID_UTILIZADOR%TYPE;
  v_filme        ALUGUERES.FILMES_ID_FILME%TYPE;
  v_se_oferece   NUMBER;
  v_filme_oferta NUMBER;
  v_nome_filme   FILMES.TITULO%TYPE;
  BEGIN
    SELECT SEQ_ALUGUERES.nextval
    INTO v_id
    FROM dual;

    SELECT ID_FILME
    INTO v_filme
    FROM FILMES
    WHERE TITULO = p_filme;

    INSERT INTO ALUGUERES (ID_ALUGUER, UTILIZADORES_ID_UTILIZADOR, FILMES_ID_FILME)
    VALUES (v_id, p_id_utilizador, v_filme);

    SELECT FUN_CALC_SE_OFERECE(p_id_utilizador)
    INTO v_se_oferece
    FROM dual;

    dbms_output.put_line(v_se_oferece);

    IF (v_se_oferece = 1)
    THEN
      SELECT FUN_CALC_FILME_OFERTA(p_id_utilizador)
      INTO v_filme_oferta
      FROM dual;
      SELECT SEQ_ALUGUERES.nextval
      INTO v_id_of
      FROM dual;

      dbms_output.put_line(v_nome_filme);

      INSERT INTO ALUGUERES (ID_ALUGUER, UTILIZADORES_ID_UTILIZADOR, FILMES_ID_FILME)
      VALUES (v_id_of, p_id_utilizador, v_filme_oferta);

    END IF;
  END;