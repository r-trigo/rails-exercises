create PROCEDURE proc_select_filmes AS
  v_filmes FILMES%ROWTYPE;
  CURSOR c_filmes IS SELECT *
                     FROM FILMES;
  BEGIN
    OPEN c_filmes;
    LOOP FETCH c_filmes INTO v_filmes;
      EXIT WHEN c_filmes%NOTFOUND;

      dbms_output.put_line(v_filmes.TITULO);
      --htp.p(v_filmes);
    END LOOP;
  END;