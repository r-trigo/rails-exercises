create PROCEDURE proc_insert_log(p_username VARCHAR2, p_ip VARCHAR2) AS
  v_id_utilizador NUMBER;
  BEGIN
    SELECT ID_UTILIZADOR INTO v_id_utilizador
    FROM UTILIZADORES WHERE USERNAME = p_username;
    INSERT INTO LOGS (ID_LOG, DATA_INICIO, ENDERECO_IP, UTILIZADORES_ID_UTILIZADOR)
    VALUES (seq_logs.nextval, sysdate, p_ip, v_id_utilizador);

    -- NAO PRECISA DE OUTPUT
  END proc_insert_log;