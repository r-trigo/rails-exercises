create PROCEDURE proc_reco_data(p_id_utilizador NUMBER) AS
  v_nome_filme FILMES.TITULO%TYPE;
  BEGIN
    SELECT TITULO
    INTO v_nome_filme
    FROM FILMES
    WHERE ID_FILME NOT IN (
      SELECT FILMES_ID_FILME
      FROM ALUGUERES
      WHERE UTILIZADORES_ID_UTILIZADOR = p_id_utilizador
    )
    ORDER BY DATA_ADICIONADO DESC
    FETCH FIRST 1 ROW ONLY;
    dbms_output.put_line(v_nome_filme);
  END;