create FUNCTION FUN_VALIDA_LOGIN(
  p_username VARCHAR2,
  p_password VARCHAR2)
  RETURN BOOLEAN
IS
  v_username    VARCHAR2(50);
  v_password    VARCHAR2(100);
  v_user_existe NUMBER;
  BEGIN
    SELECT COUNT(*)
    INTO v_user_existe
    FROM UTILIZADORES
    WHERE USERNAME = p_username
          AND PASSWORD = p_password;
    IF v_user_existe = 1
    THEN
      SELECT
        USERNAME,
        PASSWORD
      INTO v_username,
        v_password
      FROM UTILIZADORES
      WHERE USERNAME = p_username
            AND PASSWORD = p_password;
      IF v_username = p_username AND v_password = p_password
      THEN
        RETURN TRUE;
      END IF;
    END IF;
    RETURN FALSE;
  END FUN_VALIDA_LOGIN;