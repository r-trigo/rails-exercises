create PROCEDURE proc_confirmar_aluguer(p_id_utilizador NUMBER, p_ids_filmes VARCHAR2) AS
  v_saldo       UTILIZADORES.saldo%TYPE;
  v_nome_filme  FILMES.TITULO%TYPE;
  v_id_filme    FILMES.id_filme%TYPE;
  v_preco_filme FILMES.preco_base%TYPE;
  CURSOR c_filmes IS
    SELECT regexp_substr(p_ids_filmes, '[^, ]+', 1, level) AS id_filmes
    FROM dual
    CONNECT BY regexp_substr(p_ids_filmes, '[^, ]+', 1, level) IS NOT NULL;
  BEGIN
    SELECT SALDO
    INTO v_saldo
    FROM UTILIZADORES
    WHERE ID_UTILIZADOR = p_id_utilizador;

    dbms_output.put_line(p_id_utilizador || ',' || v_saldo);

    OPEN c_filmes;
    LOOP FETCH c_filmes INTO v_id_filme;
      EXIT WHEN c_filmes%NOTFOUND;

      SELECT
        TITULO,
        PRECO_BASE
      INTO v_nome_filme, v_preco_filme
      FROM FILMES
      WHERE ID_FILME = v_id_filme;
      v_saldo := v_saldo - v_preco_filme;

      dbms_output.put_line(v_nome_filme || ', ' || p_id_utilizador || ', ' || v_saldo);

      proc_insert_alugueres(p_id_utilizador, v_nome_filme);
    END LOOP;
    CLOSE c_filmes;

    UPDATE UTILIZADORES
    SET SALDO = v_saldo
    WHERE ID_UTILIZADOR = p_id_utilizador;
    COMMIT;
  END;