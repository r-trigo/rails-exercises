create PROCEDURE PROC_LOGIN(
  p_username VARCHAR2,
  p_password VARCHAR2,
  p_ip       VARCHAR2)
IS
  v_username    VARCHAR2(50);
  v_password    VARCHAR2(100);
  v_json        CLOB;
  v_user_existe BOOLEAN;
  v_ativado     UTILIZADORES.ATIVADO%TYPE;
  BEGIN
    SELECT ATIVADO
    INTO v_ativado
    FROM UTILIZADORES;
    v_user_existe := FUN_VALIDA_LOGIN(p_username, p_password);
    IF v_user_existe = TRUE AND v_ativado = 1
    THEN
      v_json := fun_get_este_utilizador(p_username, p_password);
      PROC_INSERT_LOG(p_username, p_ip);
      COMMIT;
    ELSE
      IF v_ativado = 0
      THEN
        v_json := '{"mensagem":"Utilizador Desativado"}';
      ELSE
        v_json := '{"mensagem":"Username ou password errados!"}';
      END IF;
    END IF;
    dbms_output.put_line(v_json);
    --htp.p(v_resultado);
  END PROC_LOGIN;