create PROCEDURE proc_insert_users
  (p_foto   CLOB, p_username VARCHAR2, p_password VARCHAR2, p_nome_completo VARCHAR2,
   p_morada VARCHAR2, p_telemovel VARCHAR2, p_email VARCHAR2, p_data_nascimento DATE,
   p_nic    VARCHAR2, p_nif VARCHAR2, paises_id_pais NUMBER) AS
  v_id         UTILIZADORES.ID_UTILIZADOR%TYPE;
  v_permissoes UTILIZADORES.NIVEL_PERMISSOES%TYPE;
  v_idade      UTILIZADORES.IDADE%TYPE;
  v_saldo      UTILIZADORES.SALDO%TYPE;
  v_ativado    UTILIZADORES.ATIVADO%TYPE;
  BEGIN
    v_permissoes := 2;
    v_idade := F_CALCULA_IDADE(p_data_nascimento);
    v_ativado := 1;
    v_saldo := 0;
    SELECT SEQ_UTILIZADOR.nextval
    INTO v_id
    FROM dual;
    INSERT INTO UTILIZADORES (ID_UTILIZADOR, FOTO, USERNAME, PASSWORD, NIVEL_PERMISSOES, NOME_COMPLETO, MORADA, TELEMOVEL, EMAIL, DATA_NASCIMENTO,
                              NIC, NIF, IDADE, SALDO, ATIVADO, PAISES_ID_PAIS) VALUES
      (v_id, p_foto, p_username, p_password, v_permissoes, p_nome_completo, p_morada, p_telemovel, p_email,
             p_data_nascimento,
             p_nic, p_nif,
       v_idade, v_saldo, v_ativado, paises_id_pais);
  END;