create PROCEDURE proc_update_utilizador(p_id_utilizador NUMBER, p_foto CLOB, p_password VARCHAR2,
                                                   p_morada        VARCHAR2, p_telemovel VARCHAR2, p_email VARCHAR2) AS
  BEGIN
    UPDATE UTILIZADORES
    SET FOTO = p_foto, PASSWORD = p_password, MORADA = p_morada, TELEMOVEL = p_telemovel, EMAIL = p_email
    WHERE ID_UTILIZADOR = p_ID_UTILIZADOR;
  END;