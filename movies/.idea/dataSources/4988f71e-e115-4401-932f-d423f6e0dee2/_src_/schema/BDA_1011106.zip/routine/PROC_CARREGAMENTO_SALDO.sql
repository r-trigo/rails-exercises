create PROCEDURE proc_carregamento_saldo(p_username VARCHAR2, p_quantia NUMBER) AS
  v_json CLOB;
  v_saldo UTILIZADORES.SALDO%TYPE;
  BEGIN
    SELECT SALDO INTO v_saldo FROM UTILIZADORES WHERE USERNAME LIKE p_username;
    v_saldo := v_saldo + p_quantia;
    UPDATE UTILIZADORES
    SET SALDO = v_saldo
    WHERE USERNAME = p_username;

    v_json := '{"resultado": [{"mensagem":"sucesso!"}]}';

    dbms_output.put_line(v_json);
    --htp.p(v_json);
    commit;
  END;