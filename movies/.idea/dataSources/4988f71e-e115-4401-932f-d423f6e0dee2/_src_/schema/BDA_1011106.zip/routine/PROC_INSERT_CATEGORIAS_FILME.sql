create PROCEDURE proc_insert_categorias_filme(p_id_filme NUMBER, p_ids_categorias VARCHAR2) AS
  v_categoria NUMBER;
  CURSOR c_cats IS SELECT regexp_substr(p_ids_categorias, '[^, ]+', 1, level) AS categoria
                   FROM dual
                   CONNECT BY regexp_substr(p_ids_categorias, '[^, ]+', 1, level) IS NOT NULL;
  BEGIN OPEN c_cats;
    LOOP FETCH c_cats INTO v_categoria;
      EXIT WHEN c_cats%NOTFOUND;
      INSERT INTO LISTA_CATEGORIAS_FILME (FILMES_ID_FILME, CATEGORIAS_ID_CATEGORIA) VALUES (p_id_filme, v_categoria);
    END LOOP;
    CLOSE c_cats;
  END;