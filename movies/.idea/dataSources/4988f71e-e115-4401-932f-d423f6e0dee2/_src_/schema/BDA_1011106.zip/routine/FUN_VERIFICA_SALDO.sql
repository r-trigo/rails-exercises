create FUNCTION FUN_VERIFICA_SALDO(p_id_utilizador NUMBER, p_custo_carrinho NUMBER)
  RETURN NUMBER AS
  v_saldo UTILIZADORES.saldo%TYPE;
  BEGIN
    SELECT SALDO
    INTO v_saldo
    FROM UTILIZADORES
    WHERE ID_UTILIZADOR = p_id_utilizador;

    IF p_custo_carrinho > v_saldo
    THEN
      --erro
      RETURN 1;
    ELSE
      --sucesso
      RETURN 0;
    END IF;
  END;