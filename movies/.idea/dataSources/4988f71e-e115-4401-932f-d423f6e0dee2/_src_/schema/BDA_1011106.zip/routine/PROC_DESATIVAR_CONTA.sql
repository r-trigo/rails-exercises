create PROCEDURE proc_desativar_conta(p_id_utilizador NUMBER, p_password VARCHAR2, p_motivo VARCHAR2) AS
  v_id_utilizador UTILIZADORES.ID_UTILIZADOR%TYPE;
  v_password      UTILIZADORES.PASSWORD%TYPE;
  BEGIN
    SELECT PASSWORD
    INTO v_password
    FROM UTILIZADORES
    WHERE ID_UTILIZADOR = p_id_utilizador;

    IF (v_password = p_password)
    THEN
      UPDATE UTILIZADORES
      SET ATIVADO = 0, INFO_DESATIVADO = p_motivo
      WHERE ID_UTILIZADOR LIKE p_id_utilizador;
    END IF;
  END;