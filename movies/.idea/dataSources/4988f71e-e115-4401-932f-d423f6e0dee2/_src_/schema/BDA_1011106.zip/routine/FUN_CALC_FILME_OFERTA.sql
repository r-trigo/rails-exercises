create FUNCTION FUN_CALC_FILME_OFERTA(p_id_utilizador NUMBER)
  RETURN NUMBER AS
  v_id_filme NUMBER;
  BEGIN
    SELECT ID_FILME
    INTO v_id_filme
    FROM FILMES
    WHERE ID_FILME NOT IN (
      --já vistos
      SELECT FILMES_ID_FILME
      FROM ALUGUERES
      WHERE UTILIZADORES_ID_UTILIZADOR = p_id_utilizador
    )
    ORDER BY dbms_random.value
    FETCH FIRST 1 ROW ONLY;

    RETURN v_id_filme;
  END;