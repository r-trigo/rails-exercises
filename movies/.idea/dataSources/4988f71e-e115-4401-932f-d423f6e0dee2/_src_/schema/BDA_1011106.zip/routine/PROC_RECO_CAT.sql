create PROCEDURE proc_reco_cat(p_id_utilizador NUMBER) AS
  v_nome_filme FILMES.TITULO%TYPE;
  BEGIN
    SELECT TITULO
    INTO v_nome_filme
    FROM FILMES
    WHERE ID_FILME NOT IN (
      --já vistos
      SELECT FILMES_ID_FILME
      FROM ALUGUERES
      WHERE UTILIZADORES_ID_UTILIZADOR = 4
    ) AND ID_FILME IN (
      --filmes da categoria mais visto
      SELECT FILMES.ID_FILME
      FROM FILMES, LISTA_CATEGORIAS_FILME
      WHERE LISTA_CATEGORIAS_FILME.CATEGORIAS_ID_CATEGORIA = 1 AND
            FILMES.ID_FILME = LISTA_CATEGORIAS_FILME.FILMES_ID_FILME
    )
    ORDER BY dbms_random.value
    FETCH FIRST 1 ROW ONLY;

    dbms_output.put_line(v_nome_filme);

  END;