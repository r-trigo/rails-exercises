create FUNCTION FUN_CALC_SE_OFERECE(p_id_utilizador NUMBER)
  RETURN NUMBER AS
  v_conta NUMBER;
  v_rem   NUMBER;
  BEGIN
    SELECT count(FILMES_ID_FILME)
    INTO v_conta
    FROM ALUGUERES
    WHERE UTILIZADORES_ID_UTILIZADOR = p_id_utilizador;

    IF (v_conta >= 5)
    THEN
      RETURN 1;
    ELSE
      RETURN 0;
    END IF;
  END;