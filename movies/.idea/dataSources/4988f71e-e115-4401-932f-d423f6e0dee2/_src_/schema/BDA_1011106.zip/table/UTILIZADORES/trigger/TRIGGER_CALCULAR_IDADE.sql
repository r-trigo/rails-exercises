create trigger TRIGGER_CALCULAR_IDADE
	before insert
	on UTILIZADORES
	for each row
BEGIN
    :new.IDADE := F_CALCULA_IDADE(:new.DATA_NASCIMENTO);
END;