create trigger TRIGGER_RECALCULAR_IDADE
	after insert
	on LOGS
	for each row
DECLARE
    DN  DATE;
    AGE NUMBER;
  BEGIN
    SELECT data_nascimento
    INTO DN
    FROM utilizadores
    WHERE ID_UTILIZADOR = :New.Utilizadores_ID_UTILIZADOR;
    AGE := F_CALCULA_IDADE(DN);
    /*select floor(months_between(sysdate,DN)/12) into AGE from dual;*/
    UPDATE utilizadores
    SET idade = age
    WHERE ID_UTILIZADOR = :New.Utilizadores_ID_UTILIZADOR;
END;