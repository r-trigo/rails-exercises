create trigger TRIGGER_DURACAO_ALUGUER
	before insert
	on ALUGUERES
	for each row
DECLARE DATA_I DATE;
    DATA_F       DATE;
    DIAS         NUMBER;
  BEGIN
    DATA_I := SYSDATE;
    DATA_F := SYSDATE + 2;
    DIAS := DATA_F - DATA_I;
    :NEW.DATA_INICIO := DATA_I;
    :NEW.DATA_FIM := DATA_F;
    :NEW.DIAS_DURACAO := DIAS;
END;