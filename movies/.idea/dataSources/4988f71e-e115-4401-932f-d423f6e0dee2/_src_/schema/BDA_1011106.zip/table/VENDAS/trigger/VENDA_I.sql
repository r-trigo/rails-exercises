create trigger VENDA_I
	before insert
	on VENDAS
	for each row
declare
  --v_aux number(9);
  v_preco artigos.preco%type;
begin
  select preco into v_preco from artigos where id = :new.artigo;
  :new.total := :new.qt * v_preco;
end;